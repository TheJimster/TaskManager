Thank you for leveraging these resources. If you do plan on using them, here are my suggestions:

Resize your image! The images provided are larger than you will most likely want to use. The 
	standardard set for using QR-Images in documents is typically in a 2cm x 2cm square.